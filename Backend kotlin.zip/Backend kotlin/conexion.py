from datetime import timedelta
import os
from random import randint
from flask import Flask, jsonify
import mysql.connector

app = Flask(__name__)
app.secret_key = str(randint(100000,999999))
miDB = mysql.connector.connect(host="localhost",
                               port="3306",
                               user="root",
                               password="",
                               database="vsco")
cursor = miDB.cursor()