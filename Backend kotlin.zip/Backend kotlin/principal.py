from conexion import *
from rutas.inicio_sesion import *
from rutas.registro import *
from rutas.consultar_publis import *
from rutas.insertar_publicacion import *
from rutas.actualizar_publi import *
from rutas.eliminar_publi import *


@app.route("/")
def raiz():
    return "Hola, Andres Vivas"


if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)