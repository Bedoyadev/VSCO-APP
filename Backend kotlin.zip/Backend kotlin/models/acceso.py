from conexion import *

class Acceso:
    
    def verficar_acceso(self,correo,contra):
            sql = "SELECT * FROM usuarios WHERE correo_electronico = %s AND contrasena = %s"
            cursor.execute(sql,(correo,contra))
            resultado = cursor.fetchall()
            return resultado
        



usuario = Acceso()