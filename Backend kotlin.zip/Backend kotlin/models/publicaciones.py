from conexion import *

class Publicaciones:

    def consultar(self, correo):
            sql = "SELECT * FROM publicaciones WHERE usuario = %s"
            cursor.execute(sql,(correo,))
            datos = cursor.fetchall()
            publicaciones = [{"id": f[0],"correo":f[1],"titulo": f[2], "descripcion": f[3], "imagen": f[4]} for f in datos]
            print(publicaciones)    
            return jsonify(publicaciones), 200
    
    def actualizar(self,datos):
        titulo = datos['titulo']
        descripcion = datos['descripcion']
        imagen = datos['imagen']
        id = datos['id']
        sql = "UPDATE publicaciones set titulo = %s, descripcion =%s, url_foto= %s WHERE id_publicacion = %s"
        print(datos)
        cursor.execute(sql,(titulo,descripcion,imagen,id))
        miDB.commit()
        return True
    
   
         
          
          

publicacion = Publicaciones()