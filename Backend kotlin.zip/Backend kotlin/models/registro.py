from conexion import *

class Registro:

    def insertar(self,datos):
            sql = "INSERT INTO usuarios (correo_electronico, nombre_perfil, contrasena, fecha_nacimiento) VALUES (%s, %s, %s,%s)"
            cursor.execute(sql,datos)
            miDB.commit()
            
    def verificar_correo(self,correo):
          sql = "SELECT * FROM usuarios where correo_electronico = %s"
          cursor.execute(sql,(correo,))
          resultado = cursor.fetchall()
          if resultado:
                return True
          else:
                return False


        

regis = Registro()