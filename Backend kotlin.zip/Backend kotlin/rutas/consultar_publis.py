from rutas.inicio_sesion import *
from conexion import *
from rutas.registro import *
from models.publicaciones import *


@app.route('/consultarPublicaciones', methods=['POST'])
def consulta_supervisor():
    datos = request.get_json()
    correo = datos['correo']
    return publicacion.consultar(correo)
    

