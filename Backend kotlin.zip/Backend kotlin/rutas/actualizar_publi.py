from rutas.insertar_publicacion import *
from rutas.inicio_sesion import *
from conexion import *
from rutas.registro import *
from rutas.consultar_publis import *


@app.route("/actualizar_publicaciones", methods=['PUT'])
def actualizar():
    try:
        datos = request.get_json()
        resultado = publicacion.actualizar(datos)
        if resultado == True:
            return jsonify({"success": True}),200
        else:
            return jsonify({"Bad":"No se pudo actualizar los datos"}),400
    except Exception as e: 
        return jsonify({"error": str(e)}), 400
