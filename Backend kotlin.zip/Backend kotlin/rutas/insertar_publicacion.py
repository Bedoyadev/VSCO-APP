from datetime import datetime
from rutas.inicio_sesion import *
from conexion import *
from rutas.registro import *
from rutas.consultar_publis import *

@app.route("/insertar_publicaciones", methods = ['POST'])
def insertar():
        datos = request.get_json()
        titulo = datos['titulo']
        descripcion = datos['descripcion']
        usuario = datos['correo']
        imagen = datos['imagen']
        cursor.execute("INSERT INTO publicaciones(usuario, titulo, descripcion, url_foto) values (%s,%s,%s,%s)", 
                       (usuario, titulo, descripcion, imagen))
        miDB.commit()
        id_generado = cursor.lastrowid
        return jsonify(id_generado), 200
        
    