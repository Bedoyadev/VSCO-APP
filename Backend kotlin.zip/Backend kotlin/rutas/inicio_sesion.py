import hashlib
from flask import Flask, jsonify,request,session
from conexion import *
from models.acceso import *

@app.route("/login", methods=['POST'])
def inicio_sesion():
    datos = request.get_json()
    correo = datos['correo']
    contrasena = datos['contrasena']
    cifrada = hashlib.sha512(contrasena.encode("utf-8")).hexdigest()
    resultado = usuario.verficar_acceso(correo, cifrada)
    if len(resultado) > 0:
        session['correo'] = correo
        nombre = resultado [0][1]
        return jsonify({"nombre": nombre}), 200
    else:
        return jsonify({"error": "Credenciales incorrectas"}), 401

