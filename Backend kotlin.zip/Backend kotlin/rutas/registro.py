import hashlib
from rutas.inicio_sesion import *
from conexion import *
from models.registro import *


@app.route("/registro", methods = ['POST'])
def registro():
        datos = request.get_json()
        correo = datos['correo']
        usuario= datos['usuario']
        contrasena1= datos['contrasena']
        cumple = datos['cumple']
        verificar_correo = regis.verificar_correo(correo)
        if verificar_correo == False:
            cifrada = hashlib.sha512(contrasena1.encode("utf-8")).hexdigest()
            datos = (correo,usuario,cifrada,cumple)
            regis.insertar(datos)
            return jsonify({"success": True}), 200
        else:
            return jsonify({"error": False}), 401
    
