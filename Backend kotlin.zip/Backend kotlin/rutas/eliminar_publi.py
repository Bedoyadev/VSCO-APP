from rutas.insertar_publicacion import *
from rutas.inicio_sesion import *
from conexion import *
from rutas.registro import *
from rutas.consultar_publis import *
from rutas.actualizar_publi import *

@app.route("/eliminar_publicacion/<int:id>", methods =['DELETE'])
def eliminar(id):
    try:
        print("ID recibido:", id)
        sql = "DELETE FROM publicaciones WHERE id_publicacion = %s"
        cursor.execute(sql, (id,))
        miDB.commit()
        return jsonify({"success": True}), 200
    except Exception as e:
        return jsonify({"error": "Ha ocurrido un error"}), 400
